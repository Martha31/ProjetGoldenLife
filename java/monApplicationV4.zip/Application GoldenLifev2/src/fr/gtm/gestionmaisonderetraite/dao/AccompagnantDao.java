package fr.gtm.gestionmaisonderetraite.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import fr.gtm.gestionmaisonderetraite.domaine.Accompagnant;

/**
 * @author Melissa 
 *
 */

public class AccompagnantDao implements IGestionAccompagnant {

	/* (non-Javadoc)
	 * @see fr.gtm.gestionmaisonderetraite.dao.IGestionAccompagnant#getAccompagnant(int)
	 */
	@Override
	public Accompagnant getAccompagnant(int accompagnantId) {

		Accompagnant accompagnant = new Accompagnant();

		// Information d'acc�s � la base de donn�es
		String url = "jdbc:mysql://localhost/maisonderetraite";
		String login = "root";
		String passwd = "";
		Connection cn = null;
		Statement st = null;

		try {

			// Etape 1 : Chargement du driver
			Class.forName("com.mysql.jdbc.Driver");

			// Etape 2 : r�cup�ration de la connexion
			cn = DriverManager.getConnection(url, login, passwd);

			// Etape 3 : Pr�parer la requ�te
			st = cn.createStatement();

			String sql = "SELECT `accompagnantId`, `emailId`, `nom`, `prenom` FROM `accompagnant` WHERE `accompagnantId` = "
					+ accompagnantId + ";";

			// Etape 4 : ex�cution requ�te
			ResultSet rs = st.executeQuery(sql);

			rs.next();
			String emailId = rs.getString("emailId");
			String nom = rs.getString("nom");
			String prenom = rs.getString("prenom");
			System.out.println("L'accompagnant " + nom + " " + prenom);

			accompagnant.setEmailId(emailId);
			accompagnant.setNom(nom);
			accompagnant.setPrenom(prenom);

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO: gestion erreur
			e.printStackTrace();

		} finally {
			try {
				// Etape 6 : lib�rer ressources de la m�moire.
				cn.close();
				st.close();
			} catch (SQLException e) {
				// TODO: gestion erreur
				e.printStackTrace();
			}
		}
		return accompagnant;
	}

	/* (non-Javadoc)
	 * @see fr.gtm.gestionmaisonderetraite.dao.IGestionAccompagnant#getAllAccompagnant()
	 */
	@Override
	public ArrayList<Accompagnant> getAllAccompagnant() {

		// Information d'acc�s � la base de donn�es
		String url = "jdbc:mysql://localhost/maisonderetraite";
		String login = "root";
		String passwd = "";
		Connection cn = null;
		Statement st = null;

		// Cr�ation de la liste des accompagnants de la maison de retraite
		ArrayList<Accompagnant> listeAccompagnant = new ArrayList<Accompagnant>();

		try {

			// Etape 1 : Chargement du driver
			Class.forName("com.mysql.jdbc.Driver");

			// Etape 2 : r�cup�ration de la connexion
			cn = DriverManager.getConnection(url, login, passwd);

			// Etape 3 : Pr�parer la requ�te
			st = cn.createStatement();

			String sql = "SELECT * FROM `accompagnant`";
			// Etape 4 : ex�cution requ�te

			ResultSet rs = st.executeQuery(sql);

			while (rs.next()) {
				int id = rs.getInt("id");
				String emailId = rs.getString("emailId");
				String nom = rs.getString("nom");
				String prenom = rs.getString("prenom");
				System.out.println("L'accompagnant " + nom + " " + prenom);

				// Creation d'un nouvel accompagnat
				Accompagnant a = new Accompagnant(emailId, nom, prenom);
				listeAccompagnant.add(a);
			}

			// System.out.println("Insertion en base OK");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO: gestion erreur
			e.printStackTrace();
		} finally {
			try {
				// Etape 6 : lib�rer ressources de la m�moire.
				cn.close();
				st.close();
			} catch (SQLException e) {
				// TODO: gestion erreur
				e.printStackTrace();
			}
		}
		return listeAccompagnant;

	}
}