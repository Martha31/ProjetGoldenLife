package fr.gtm.gestionmaisonderetraite.dao;

import java.util.ArrayList;

import fr.gtm.gestionmaisonderetraite.domaine.Accompagnant;

public interface IGestionAccompagnant {

	Accompagnant getAccompagnant(int accompagnantId);

	ArrayList<Accompagnant> getAllAccompagnant();

}