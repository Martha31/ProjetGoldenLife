package fr.gtm.gestionmaisonderetraite.dao;

import java.util.ArrayList;

import fr.gtm.gestionmaisonderetraite.domaine.Resident;

public interface IGestionResident {

	Resident getResident(int matricule);

	ArrayList<Resident> getAllResident();

}