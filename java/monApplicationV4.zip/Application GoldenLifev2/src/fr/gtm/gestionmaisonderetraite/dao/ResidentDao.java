package fr.gtm.gestionmaisonderetraite.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import fr.gtm.gestionmaisonderetraite.domaine.Resident;

public class ResidentDao implements IGestionResident {

	/* (non-Javadoc)
	 * @see fr.gtm.gestionmaisonderetraite.dao.IGestionResident#getResident(int)
	 */
	@Override
	public Resident getResident(int matricule) {
			
		Resident resident = new Resident();

		// Information d'acc�s � la base de donn�es
		String url = "jdbc:mysql://localhost/maisonderetraite";
		String login = "root";
		String passwd = "";
		Connection cn = null;
		Statement st = null;

		try {

			// Etape 1 : Chargement du driver
			Class.forName("com.mysql.jdbc.Driver");

			// Etape 2 : r�cup�ration de la connexion
			cn = DriverManager.getConnection(url, login, passwd);

			// Etape 3 : Pr�parer la requ�te
			st = cn.createStatement();

			String sql = "SELECT `accompagnantId`, `matricule`, `nom`, `prenom`, `age` FROM `resident` WHERE `matricule` = "
					+ matricule + ";";

			// Etape 4 : ex�cution requ�te
			ResultSet rs = st.executeQuery(sql);

			rs.next();
			int matricule1 = rs.getInt("matricule");
			String nom = rs.getString("nom");
			String prenom = rs.getString("prenom");
			int age1 = rs.getInt("age");
			System.out.println("Le r�sident " + nom + " " + prenom);

			resident.setMatricule(matricule1);
			resident.setNom(nom);
			resident.setPrenom(prenom);

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			//  gestion erreur
			e.printStackTrace();

		} finally {
			try {
				// Etape 6 : lib�rer ressources de la m�moire.
				cn.close();
				st.close();
			} catch (SQLException e) {
				//  gestion erreur
				e.printStackTrace();
			}
		}
		return resident;
	}

	/* (non-Javadoc)
	 * @see fr.gtm.gestionmaisonderetraite.dao.IGestionResident#getAllResident()
	 */
	@Override
	public ArrayList<Resident> getAllResident() {

		// Information d'acc�s � la base de donn�es
		String url = "jdbc:mysql://localhost/maisonderetraite";
		String login = "root";
		String passwd = "";
		Connection cn = null;
		Statement st = null;

		// Cr�ation de la liste des resident de la maison de retraite
		ArrayList<Resident> listeResident = new ArrayList<Resident>();

		try {

			// Etape 1 : Chargement du driver
			Class.forName("com.mysql.jdbc.Driver");

			// Etape 2 : r�cup�ration de la connexion
			cn = DriverManager.getConnection(url, login, passwd);

			// Etape 3 : Pr�parer la requ�te
			st = cn.createStatement();

			String sql = "SELECT * FROM `resident`";

			// Etape 4 : ex�cution requ�te
			ResultSet rs = st.executeQuery(sql);

			while (rs.next()) {
				int matricule = rs.getInt("matricule");
				String nom = rs.getString("nom");
				String prenom = rs.getString("prenom");
				int age = rs.getInt("age");
				System.out.println("Le r�sident " + nom + " " + prenom);

				// Creation d'un r�sident
				Resident r = new Resident(matricule, nom, prenom, age);
				listeResident.add(r);
			}

			// System.out.println("Insertion en base OK");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO: gestion erreur
			e.printStackTrace();
		} finally {
			try {
				// Etape 6 : lib�rer ressources de la m�moire.
				cn.close();
				st.close();
			} catch (SQLException e) {
				// TODO: gestion erreur
				e.printStackTrace();
			}
		}
		return listeResident;

	}
}
