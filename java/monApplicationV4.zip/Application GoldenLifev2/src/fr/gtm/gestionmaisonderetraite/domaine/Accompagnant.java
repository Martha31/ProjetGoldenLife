package fr.gtm.gestionmaisonderetraite.domaine;

/**
 * @author Melissa
 *
 */

public class Accompagnant {
	// Les propri�t�s d'un accompagnant
	private String emailId;
	private String nom;
	private String prenom;

	// Getters et Setters
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	// Constructeur
	public Accompagnant(String emailId, String nom, String prenom) {
		super();
		this.emailId = emailId;
		this.nom = nom;
		this.prenom = prenom;
	}

	public Accompagnant() {
		// TODO Auto-generated constructor stub
	}

}
