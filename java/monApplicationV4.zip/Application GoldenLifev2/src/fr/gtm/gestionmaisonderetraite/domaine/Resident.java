package fr.gtm.gestionmaisonderetraite.domaine;

/**
 * @author Melissa
 *
 */

public class Resident {
	// Les propri�t�s d'un r�sident
	private int matricule;
	private String nom;
	private String prenom;
	private int age;

	// Getters et Setters
	public int getMatricule() {
		return matricule;
	}

	public void setMatricule(int matricule) {
		this.matricule = matricule;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	// Constructeur
	public Resident(int matricule, String nom, String prenom, int age) {
		super();
		this.matricule = matricule;
		this.nom = nom;
		this.prenom = prenom;
		this.age = age;
	}

	public Resident() {
		// TODO Auto-generated constructor stub
	}

}
