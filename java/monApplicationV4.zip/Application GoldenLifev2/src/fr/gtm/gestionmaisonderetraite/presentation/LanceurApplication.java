package fr.gtm.gestionmaisonderetraite.presentation;

import fr.gtm.gestionmaisonderetraite.service.AccompagnantService;
import fr.gtm.gestionmaisonderetraite.service.ResidentService;

public class LanceurApplication {

	public static void main(String[] args) {
		// Affichage d'un accompagnant
		AccompagnantService as = new AccompagnantService();
		as.recupereAAccompagnant(4);
		
		
		// Affichage d'un r�sident
		ResidentService rs = new ResidentService();
		rs.recupereResident(4);
	}
		 
		
	
}
