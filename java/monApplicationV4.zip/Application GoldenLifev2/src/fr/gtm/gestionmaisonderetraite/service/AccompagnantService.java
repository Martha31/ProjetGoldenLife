package fr.gtm.gestionmaisonderetraite.service;

import java.util.ArrayList;

import fr.gtm.gestionmaisonderetraite.dao.AccompagnantDao;
import fr.gtm.gestionmaisonderetraite.dao.IGestionAccompagnant;
import fr.gtm.gestionmaisonderetraite.domaine.Accompagnant;
import fr.gtm.gestionmaisonderetraite.domaine.Resident;

public class AccompagnantService {

	// Un accompagnant a en charge le suivi de r�sident
	public void soignerResident(Accompagnant accompagnanta, Resident resident) {
	}

	// M�thodes obtenir liste et afficher accompagnant pr�sentes dans la couche Dao
	private IGestionAccompagnant accompagnantDao;

	public ArrayList<Accompagnant> getListeAccompagnant() {
		accompagnantDao = new AccompagnantDao();
		return accompagnantDao.getAllAccompagnant();
	}

	public Accompagnant recupereAAccompagnant(int accompagnantId) {
		accompagnantDao = new AccompagnantDao();
		return accompagnantDao.getAccompagnant(accompagnantId);
	}

}
