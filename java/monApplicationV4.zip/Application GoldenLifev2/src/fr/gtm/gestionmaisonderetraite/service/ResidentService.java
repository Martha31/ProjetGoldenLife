package fr.gtm.gestionmaisonderetraite.service;

import java.util.ArrayList;

import fr.gtm.gestionmaisonderetraite.dao.IGestionResident;
import fr.gtm.gestionmaisonderetraite.dao.ResidentDao;
import fr.gtm.gestionmaisonderetraite.domaine.Resident;

/**
 * @author Melissa 
 *
 */

public class ResidentService {

	private IGestionResident residentDao;

	public ArrayList<Resident> getListeResident() {
		residentDao = new ResidentDao();
		return residentDao.getAllResident();
	}

	public Resident recupereResident(int matricule) {
		residentDao = new ResidentDao();
		return residentDao.getResident(matricule);
	}

}
